import cdmSvc from 'soa/kernel/clientDataModel';
import soaService from 'soa/kernel/soaService';

let Workflowuid = null;
let WorkflowName = null;

export let assignToWorkflow = function (text, objectname) {
    let contextObject = cdmSvc.getObject(text);
    console.log("The Selected item id is :", objectname);

    
    soaService.post('Workflow-2008-06-Workflow', 'getWorkflowTemplates', {
        targets: [contextObject],
        allOrAssignedCriteria: "SOA_EPM_All"
    }).then(function (response) {
        let WorkflowTemplates = response.workflowTemplates;
        WorkflowTemplates.forEach(template => {
            let TemplateName = template.props.object_name.dbValues[0];

            if (TemplateName === "TCM Release Process") {
                Workflowuid = template.uid;
                WorkflowName=TemplateName;
                console.log("Found Workflow uid is:", Workflowuid);
                console.log("Found the desired template:", TemplateName);
            }
        });

        let requestPayload = {
            startImmediately: true,
            observerKey: "",
            name: `${WorkflowName} : ${objectname}`,  
            subject: "",
            description: "",
            contextData: {
                processTemplate: WorkflowName,
                processOwner: "",
                dependencyTask: "",
                subscribeToEvents: false,
                subscriptionEventCount: 0,
                subscriptionEventList: [],
                remoteParent: "",
                remoteParentAppguid: "",
                remoteParentUrl: "",
                attachmentCount: 1,
                attachments: [text],
                attachmentTypes: [1],
                deadlineDate: "",
                container: "",
                relationType: "",
                processAssignmentList: "",
                processResources: []
            }
        };

        soaService.post('Workflow-2008-06-Workflow', 'createInstance', requestPayload).then(function (response) {
            console.log("Workflow instance created successfully", response);
        }).catch(function (error) {
            console.log("Error creating workflow instance", error);
        });
    }).catch(function (error) {
        console.log('SOA error ::', error);
    });
};

export default {
    assign: assignToWorkflow
};
