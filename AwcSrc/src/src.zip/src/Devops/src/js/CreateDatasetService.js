
import appCtxSvc from 'js/appCtxService';
import AwPromiseService from 'js/awPromiseService';
import AwHttpService from 'js/awHttpService';
import $ from 'jquery';

var exports = {};


/**
 * update data for showcaseTickets
 *
 * @param {Object} fileDate key string value the location of the file
 */
export let uploadPicture = function( fileData ) {
    var deferred = AwPromiseService.instance.defer();
    if( fileData ) {
        appCtxSvc.ctx.HostedFileNameContext = {};
        appCtxSvc.ctx.HostedFileNameContext.filename = fileData.attachFiles;
        deferred.resolve();
    }
    console.log(fileData);
    return deferred.promise;
};
export let updateFormdata = function(fileData, data) {
    if(fileData && fileData.value) {
        var form = $('#fileUploadForm');
        data.formData = new FormData($(form)[0]); 
		data.formData.append('fmsFile', data.filename, data.fileName);
        data.formData.append(fileData.key, fileData.value);  // Append the fileData to the FormData object
		
		console.log('FormData after append:', data.formData.get(fileData.key));
    }
	console.log(data);
};
/**
 * post the attached files
 * @param { Object<FormData> } fromData: key/value pairs representing form fields and their values
 */
export let uploadFiles =  function( fileData,url, data ) {
	if(fileData && fileData.value) {
        console.log("Ent1");
        var form = $('#fileUploadForm');
        data.formData = new FormData($(form)[0]); 
		data.formData.append('fmsFile', data.filename, data.fileName);
        data.formData.append(fileData.key, fileData.value);  // Append the fileData to the FormData object
		console.log("Ent1");
		console.log('FormData after append:', data.formData.get(fileData.key));
    }
	console.log(data);
    // user need write the post logic
    let deferred = AwPromiseService.instance.defer();
    AwHttpService.instance.post( url, data.formData, {
        headers:{
            'Content-Type': 'multipart/form-data'
        }
    } ).then( response => {
        // custom logic to process the response logic
    } ).then( result => {
        deferred.resolve( result );
    } ).catch( error => {
        deferred.reject( error );
    } );
    return deferred.promise;
};

export let getSelectedFileInfo = ( fileName, formData ) => {
    return {
        dataToBeRelated: {
            attachFiles: fileName
        },
        fileInputForms: formData
    };
};

export default exports = {
    uploadPicture,
    uploadFiles,
    getSelectedFileInfo
};
