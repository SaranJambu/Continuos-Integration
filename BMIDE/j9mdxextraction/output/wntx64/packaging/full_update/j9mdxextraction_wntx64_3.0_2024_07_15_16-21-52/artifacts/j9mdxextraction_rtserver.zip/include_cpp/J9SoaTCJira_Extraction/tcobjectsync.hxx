/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#ifndef TEAMCENTER_SERVICES_TCJIRA_EXTRACTION_TCOBJECTSYNC_HXX 
#define TEAMCENTER_SERVICES_TCJIRA_EXTRACTION_TCOBJECTSYNC_HXX


#include <tcobjectsync2206.hxx>


namespace J9
{
    namespace Soa
    {
        namespace TCJira_Extraction
        {
            class TcObjectSync;
        }
    }
}


/**
 * this service update properties for esiting item and it will create new object with
 * properties if it not exist
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libj9soatcjira_extraction.dll
 * </li>
 * </ul>
 */

class J9::Soa::TCJira_Extraction::TcObjectSync
    : public J9::Soa::TCJira_Extraction::_2022_06::TcObjectSync
{};

#endif

