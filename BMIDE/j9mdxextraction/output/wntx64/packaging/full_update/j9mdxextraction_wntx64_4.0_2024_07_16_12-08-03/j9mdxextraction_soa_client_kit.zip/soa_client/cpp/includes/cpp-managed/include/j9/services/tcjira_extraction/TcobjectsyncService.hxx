/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef J9_SERVICES_TCJIRA_EXTRACTION_TCOBJECTSYNCSERVICE_HXX
#define J9_SERVICES_TCJIRA_EXTRACTION_TCOBJECTSYNCSERVICE_HXX

#include <j9/services/tcjira_extraction/_2022_06/Tcobjectsync.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <j9/services/tcjira_extraction/TCJira_Extraction_exports.h>

namespace J9
{
    namespace Services
    {
        namespace Tcjira_extraction
        {
            class TcobjectsyncService;

/**
 * this service update properties for esiting item and it will create new object with
 * properties if it not exist
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libj9soatcjira_extractionstrongmngd.dll
 * </li>
 * </ul>
 */

class J9SOATCJIRA_EXTRACTIONSTRONGMNGD_API TcobjectsyncService
    : public J9::Services::Tcjira_extraction::_2022_06::Tcobjectsync
{
public:
    /** Get the service stub. */
    static TcobjectsyncService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * .
     *
     * @param mapInput
     *        tcObjectSync service input map value map (string , string)
     *
     * @return
     *
     *
     * @version Teamcenter 14.1
     */
    virtual J9::Services::Tcjira_extraction::_2022_06::Tcobjectsync::OUTPUT tcObjectSyncOperation ( const INPUTMAP&  mapInput ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("TcobjectsyncService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <j9/services/tcjira_extraction/TCJira_Extraction_undef.h>
#endif

