/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef J9_SERVICES_TCJIRA_EXTRACTION__2022_06_TCOBJECTSYNC_HXX
#define J9_SERVICES_TCJIRA_EXTRACTION__2022_06_TCOBJECTSYNC_HXX


#include <teamcenter/soa/client/CreateInput.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <j9/services/tcjira_extraction/TCJira_Extraction_exports.h>

namespace Teamcenter { namespace Soa {  namespace Client { class CdmStream; }}}
namespace Teamcenter { namespace Soa {  namespace Client { class CdmParser; }}}
namespace J9 { namespace Services { namespace Tcjira_extraction { class TcobjectsyncRestBindingStub; }}}


namespace J9
{
    namespace Services
    {
        namespace Tcjira_extraction
        {
            namespace _2022_06
            {
                class Tcobjectsync;
/** Tcobjectsync Service */
class J9SOATCJIRA_EXTRACTIONSTRONGMNGD_API Tcobjectsync
{
public:
    /** The XSD Namespace. */
    static const std::string XSD_NAMESPACE;

    struct OUTPUT;

    typedef std::map< std::string, std::string > INPUTMAP;

    struct OUTPUT 
    {
        /**
         * TcObjectSync output value
         */
        std::string outputValue;

    private:
        friend class Teamcenter::Soa::Client::CdmParser;
        friend class J9::Services::Tcjira_extraction::TcobjectsyncRestBindingStub;

        void parse    ( Teamcenter::Soa::Client::CdmParser* _cdmParser );
    };




    /**
     * .
     *
     * @param mapInput
     *        tcObjectSync service input map value map (string , string)
     *
     * @return
     *
     *
     * @version Teamcenter 14.1
     */
    virtual J9::Services::Tcjira_extraction::_2022_06::Tcobjectsync::OUTPUT tcObjectSyncOperation ( const INPUTMAP&  mapInput ) = 0;


protected:
    virtual ~Tcobjectsync() {}
};
            }
        }
    }
}

#include <j9/services/tcjira_extraction/TCJira_Extraction_undef.h>
#endif

