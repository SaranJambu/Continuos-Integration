/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <extraction2206impl.hxx>

using namespace J9::Soa::TCJira_Extraction::_2022_06;
using namespace Teamcenter::Soa::Server;

ExtractionImpl::Output ExtractionImpl::extractionOperation ( const Input operationInput )
{
    // TODO implement operation
}


ExtractionImpl::OUTPUT ExtractionImpl::tcObjectSync ( const INPUTMAP& mapInput )
{
    // TODO implement operation
}



