/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef J9_SERVICES_TCJIRA_OBJECTSYNC_TCOBJECTSYNCSERVICE_HXX
#define J9_SERVICES_TCJIRA_OBJECTSYNC_TCOBJECTSYNCSERVICE_HXX

#include <j9/services/tcjira_objectsync/_2022_06/Tcobjectsync.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <j9/services/tcjira_objectsync/TCJira_ObjectSync_exports.h>

namespace J9
{
    namespace Services
    {
        namespace Tcjira_objectsync
        {
            class TcobjectsyncService;

/**
 * object sync service
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libj9soatcjira_objectsyncstrongmngd.dll
 * </li>
 * </ul>
 */

class J9SOATCJIRA_OBJECTSYNCSTRONGMNGD_API TcobjectsyncService
    : public J9::Services::Tcjira_objectsync::_2022_06::Tcobjectsync
{
public:
    /** Get the service stub. */
    static TcobjectsyncService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * .
     *
     * @param mapInput
     *        tcobjectsync input map (string , string)
     *
     * @return
     *
     *
     * @version Teamcenter 14.1
     */
    virtual J9::Services::Tcjira_objectsync::_2022_06::Tcobjectsync::OUTPUT tcObjectSyncOperation ( const INPUTMAP&  mapInput ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("TcobjectsyncService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <j9/services/tcjira_objectsync/TCJira_ObjectSync_undef.h>
#endif

