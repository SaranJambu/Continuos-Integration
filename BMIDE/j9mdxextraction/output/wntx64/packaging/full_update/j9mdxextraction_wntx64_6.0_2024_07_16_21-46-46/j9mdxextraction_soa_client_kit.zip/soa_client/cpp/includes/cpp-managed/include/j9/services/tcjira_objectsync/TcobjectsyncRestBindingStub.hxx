/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef J9_SERVICES_TCJIRA_OBJECTSYNC_TCOBJECTSYNCRESTBINDINGSTUB_HXX
#define J9_SERVICES_TCJIRA_OBJECTSYNC_TCOBJECTSYNCRESTBINDINGSTUB_HXX


#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>
#include <teamcenter/soa/client/internal/ModelManagerImpl.hxx>
#include <teamcenter/soa/client/internal/Sender.hxx>
#include <teamcenter/soa/client/internal/ServiceStub.hxx>

#include <j9/services/tcjira_objectsync/TcobjectsyncService.hxx>


#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <j9/services/tcjira_objectsync/TCJira_ObjectSync_exports.h>
namespace J9
{
    namespace Services
    {
        namespace Tcjira_objectsync
        {
            class TcobjectsyncRestBindingStub;
        }
    }
}


class J9SOATCJIRA_OBJECTSYNCSTRONGMNGD_API J9::Services::Tcjira_objectsync::TcobjectsyncRestBindingStub : public J9::Services::Tcjira_objectsync::TcobjectsyncService, public Teamcenter::Soa::Client::ServiceStub
{
public:
    virtual J9::Services::Tcjira_objectsync::_2022_06::Tcobjectsync::OUTPUT tcObjectSyncOperation ( const INPUTMAP&  mapInput );




    TcobjectsyncRestBindingStub( Teamcenter::Soa::Client::Sender* restSender, Teamcenter::Soa::Client::ModelManagerImpl* modelManager );
    
    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("J9::Services::Tcjira_objectsync::TcobjectsyncRestBindingStub")

private:
    Teamcenter::Soa::Client::Sender*              m_restSender;
    Teamcenter::Soa::Client::ModelManagerImpl*    m_modelManager;
};

#ifdef WIN32
#pragma warning ( pop )
#endif

#include <j9/services/tcjira_objectsync/TCJira_ObjectSync_undef.h>
#endif

