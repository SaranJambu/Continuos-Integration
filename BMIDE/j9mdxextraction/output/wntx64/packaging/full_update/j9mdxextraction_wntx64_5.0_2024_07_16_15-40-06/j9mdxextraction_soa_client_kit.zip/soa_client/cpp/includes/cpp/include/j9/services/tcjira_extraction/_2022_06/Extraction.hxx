/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2014
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef J9_SERVICES_TCJIRA_EXTRACTION__2022_06_EXTRACTION_HXX
#define J9_SERVICES_TCJIRA_EXTRACTION__2022_06_EXTRACTION_HXX

#include <teamcenter/soa/client/Marshaller.hxx>

#include <teamcenter/soa/client/CreateInput.hxx>
#include <teamcenter/soa/client/ModelObject.hxx>
#include <teamcenter/soa/client/ServiceData.hxx>
#include <teamcenter/soa/client/PartialErrors.hxx>
#include <teamcenter/soa/client/Preferences.hxx>

#include <j9/services/tcjira_extraction/TCJira_Extraction_exports.h>

namespace Teamcenter { namespace Soa {  namespace Client { class CdmStream; }}}
namespace Teamcenter { namespace Soa {  namespace Client { class CdmParser; }}}
namespace J9 { namespace Services { namespace Tcjira_extraction { class ExtractionRestBindingStub; }}}


namespace J9
{
    namespace Services
    {
        namespace Tcjira_extraction
        {
            namespace _2022_06
            {
                class Extraction;
/** Extraction Service */
class J9SOATCJIRA_EXTRACTIONSTRONG_API Extraction
{
public:
    /** The XSD Namespace. */
    static const std::string XSD_NAMESPACE;

    class Input;
    class Output;

    class J9SOATCJIRA_EXTRACTIONSTRONG_API Input : public Teamcenter::Soa::Client::Marshaller
    {
    public:
        /**
         * Object ID
         */
        std::string objectId;
        /**
         * Object type
         */
        std::string objectType;
        /**
         * Extraction Path
         */
        std::string extractionPath;

    private:
        friend class Teamcenter::Soa::Client::CdmStream;
        friend class J9::Services::Tcjira_extraction::ExtractionRestBindingStub;

        virtual void serialize( Teamcenter::Soa::Client::CdmStream* _cdmStream, const std::string& elementName="Input" ) const;
    };

    class J9SOATCJIRA_EXTRACTIONSTRONG_API Output : public Teamcenter::Soa::Client::Marshaller
    {
    public:
        /**
         * output Json Path
         */
        std::string jsonPath;

    private:
        friend class Teamcenter::Soa::Client::CdmParser;
        friend class J9::Services::Tcjira_extraction::ExtractionRestBindingStub;

        virtual void parse    ( Teamcenter::Soa::Client::CdmParser* _cdmParser );
    };




    /**
     * .
     *
     * @param operationInput
     *        operation input
     *
     * @return
     *
     *
     * @version Teamcenter 14.1
     */
    virtual J9::Services::Tcjira_extraction::_2022_06::Extraction::Output extractionOperation ( const J9::Services::Tcjira_extraction::_2022_06::Extraction::Input&  operationInput ) = 0;


protected:
    virtual ~Extraction() {}
};
            }
        }
    }
}

#include <j9/services/tcjira_extraction/TCJira_Extraction_undef.h>
#endif

