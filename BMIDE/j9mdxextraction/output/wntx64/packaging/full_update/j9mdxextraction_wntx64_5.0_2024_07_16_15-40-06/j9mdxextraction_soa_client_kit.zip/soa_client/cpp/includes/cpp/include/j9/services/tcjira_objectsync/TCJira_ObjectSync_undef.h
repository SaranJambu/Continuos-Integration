/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#include <common/library_indicators.h>


#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(IPLIB)
#define IPLIB 0
#endif

#undef J9SOATCJIRA_OBJECTSYNCSTRONG_API
#undef J9SOATCJIRA_OBJECTSYNCSTRONGEXPORT
#undef J9SOATCJIRA_OBJECTSYNCSTRONGGLOBAL
#undef J9SOATCJIRA_OBJECTSYNCSTRONGPRIVATE

