/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2015
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/

#ifndef J9_SERVICES_TCJIRA_EXTRACTION_EXTRACTIONSERVICE_HXX
#define J9_SERVICES_TCJIRA_EXTRACTION_EXTRACTIONSERVICE_HXX

#include <j9/services/tcjira_extraction/_2022_06/Extraction.hxx>



#include <teamcenter/soa/client/Connection.hxx>
#include <new> // for size_t
#include <teamcenter/soa/common/MemoryManager.hxx>

#ifdef WIN32
#pragma warning ( push )
#pragma warning ( disable : 4996  )
#endif

#include <j9/services/tcjira_extraction/TCJira_Extraction_exports.h>

namespace J9
{
    namespace Services
    {
        namespace Tcjira_extraction
        {
            class ExtractionService;

/**
 * Data Extraction in json
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libj9soatcjira_extractionstrong.dll
 * </li>
 * </ul>
 */

class J9SOATCJIRA_EXTRACTIONSTRONG_API ExtractionService
    : public J9::Services::Tcjira_extraction::_2022_06::Extraction
{
public:
    /** Get the service stub. */
    static ExtractionService* getService( Teamcenter::Soa::Client::Connection* );


    /**
     * .
     *
     * @param operationInput
     *        operation input
     *
     * @return
     *
     *
     * @version Teamcenter 14.1
     */
    virtual J9::Services::Tcjira_extraction::_2022_06::Extraction::Output extractionOperation ( const J9::Services::Tcjira_extraction::_2022_06::Extraction::Input&  operationInput ) = 0;


    SOA_CLASS_NEW_OPERATORS_WITH_IMPL("ExtractionService")

};
        }
    }
}


#ifdef WIN32
#pragma warning ( pop )
#endif

#include <j9/services/tcjira_extraction/TCJira_Extraction_undef.h>
#endif

