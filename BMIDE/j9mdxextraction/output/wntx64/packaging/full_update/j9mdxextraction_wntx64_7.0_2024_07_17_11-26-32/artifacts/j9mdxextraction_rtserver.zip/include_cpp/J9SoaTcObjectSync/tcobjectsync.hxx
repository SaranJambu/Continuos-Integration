/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#ifndef TEAMCENTER_SERVICES_TCOBJECTSYNC_TCOBJECTSYNC_HXX 
#define TEAMCENTER_SERVICES_TCOBJECTSYNC_TCOBJECTSYNC_HXX


#include <tcobjectsync2206.hxx>


namespace J9
{
    namespace Soa
    {
        namespace TcObjectSync
        {
            class TcObjectSync;
        }
    }
}


/**
 * TcObjectSync service
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libj9soatcobjectsync.dll
 * </li>
 * </ul>
 */

class J9::Soa::TcObjectSync::TcObjectSync
    : public J9::Soa::TcObjectSync::_2022_06::TcObjectSync
{};

#endif

